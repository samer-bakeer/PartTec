// ✅ UserProvider.dart — نسخة جاهزة تشمل: profile + fetchMyProfile + updateProfile + updateUserLocation
// عدّل فقط روابط الـ API داخل AppSettings حسب مشروعك.

import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:http_parser/http_parser.dart';

import '../utils/app_settings.dart';
import '../utils/session_store.dart';

class UserProfile {
  final String? name;
  final String? phone;
  final String? email;
  final String? imageUrl;
  final double? lat;
  final double? lng;

  UserProfile({
    this.name,
    this.phone,
    this.email,
    this.imageUrl,
    this.lat,
    this.lng,
  });

  factory UserProfile.fromJson(Map<String, dynamic> j) => UserProfile(
        name: j['name']?.toString(),
        phone: j['phone']?.toString(),
        email: j['email']?.toString(),
        imageUrl: j['imageUrl']?.toString(),
        lat: (j['lat'] is num)
            ? (j['lat'] as num).toDouble()
            : double.tryParse('${j['lat']}'),
        lng: (j['lng'] is num)
            ? (j['lng'] as num).toDouble()
            : double.tryParse('${j['lng']}'),
      );

  UserProfile copyWith({
    String? name,
    String? phone,
    String? email,
    String? imageUrl,
    double? lat,
    double? lng,
  }) =>
      UserProfile(
        name: name ?? this.name,
        phone: phone ?? this.phone,
        email: email ?? this.email,
        imageUrl: imageUrl ?? this.imageUrl,
        lat: lat ?? this.lat,
        lng: lng ?? this.lng,
      );
}

class UserProvider with ChangeNotifier {
  bool isSaving = false;
  bool isLoadingProfile = false;
  String? error;

  UserProfile? profile;

  // ✅ جيب بياناتي (مثال endpoint: /user/me أو /me)
  Future<void> fetchMyProfile() async {
    isLoadingProfile = true;
    error = null;
    notifyListeners();

    try {
      final uid = await SessionStore.userId();
      if (uid == null || uid.isEmpty) {
        throw Exception('لم يتم العثور على userId. الرجاء تسجيل الدخول أولاً.');
      }

      // ✅ عدّل المسار حسب API عندك
      final url = Uri.parse('${AppSettings.serverurl}/user/me/$uid');

      final res = await http.get(url);
      if (res.statusCode >= 200 && res.statusCode < 300) {
        final data = jsonDecode(res.body);
        // إذا الـ API يرجّع {user:{...}} عدّل هون
        final userJson =
            (data is Map && data['user'] != null) ? data['user'] : data;
        profile = UserProfile.fromJson(Map<String, dynamic>.from(userJson));
      } else {
        throw Exception('فشل جلب البيانات: ${res.statusCode}');
      }

      isLoadingProfile = false;
      notifyListeners();
    } catch (e) {
      error = e.toString();
      isLoadingProfile = false;
      notifyListeners();
    }
  }

  // ✅ تحديث بيانات البروفايل + صورة (multipart)
  Future<bool> updateProfile({
    required String name,
    required String phone,
    required String email,
    File? imageFile,
  }) async {
    isSaving = true;
    error = null;
    notifyListeners();

    try {
      final uid = await SessionStore.userId();
      if (uid == null || uid.isEmpty) {
        throw Exception('لم يتم العثور على userId. الرجاء تسجيل الدخول أولاً.');
      }

      // ✅ عدّل المسار حسب API عندك
      final url = Uri.parse('${AppSettings.serverurl}/user/updateProfile/$uid');

      final req = http.MultipartRequest('POST', url);

      req.fields['name'] = name;
      req.fields['phone'] = phone;
      req.fields['email'] = email;

      if (imageFile != null) {
        final fileName = imageFile.path.split('/').last;
        req.files.add(
          await http.MultipartFile.fromPath(
            'image', // ✅ اسم الحقل بالسيرفر (عدّله إذا مختلف)
            imageFile.path,
            filename: fileName,
            contentType: MediaType('image', 'jpeg'),
          ),
        );
      }

      final streamed = await req.send();
      final res = await http.Response.fromStream(streamed);

      if (res.statusCode >= 200 && res.statusCode < 300) {
        // إذا السيرفر يرجّع بيانات محدثة، استخرجها
        try {
          final data = jsonDecode(res.body);
          final userJson =
              (data is Map && data['user'] != null) ? data['user'] : data;
          profile = UserProfile.fromJson(Map<String, dynamic>.from(userJson));
        } catch (_) {
          // إذا ما رجّع JSON، حدّث محلياً على الأقل
          profile = (profile ?? UserProfile()).copyWith(
            name: name,
            phone: phone,
            email: email,
          );
        }

        isSaving = false;
        notifyListeners();
        return true;
      } else {
        error = 'فشل حفظ البيانات: ${res.statusCode}';
        isSaving = false;
        notifyListeners();
        return false;
      }
    } catch (e) {
      error = e.toString();
      isSaving = false;
      notifyListeners();
      return false;
    }
  }

  // ✅ هذه هي الدالة التي تحتاجها HomePage لتثبيت موقع المستخدم
  Future<bool> updateUserLocation({
    required double lat,
    required double lng,
  }) async {
    isSaving = true;
    error = null;
    notifyListeners();

    try {
      final uid = await SessionStore.userId();
      if (uid == null || uid.isEmpty) {
        throw Exception('لم يتم العثور على userId. الرجاء تسجيل الدخول أولاً.');
      }

      final _lat = double.parse(lat.toStringAsFixed(6));
      final _lng = double.parse(lng.toStringAsFixed(6));

      // ✅ نفس المسار الذي كتبته أنت سابقاً
      final url =
          Uri.parse('${AppSettings.serverurl}/user/updateUserLocation/$uid');

      final res = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'lat': _lat, 'lng': _lng}),
      );

      if (res.statusCode >= 200 && res.statusCode < 300) {
        // حدّث محلياً
        profile = (profile ?? UserProfile()).copyWith(lat: _lat, lng: _lng);

        isSaving = false;
        notifyListeners();
        return true;
      } else {
        error = 'فشل حفظ الموقع: ${res.statusCode}';
        isSaving = false;
        notifyListeners();
        return false;
      }
    } catch (e) {
      error = e.toString();
      isSaving = false;
      notifyListeners();
      return false;
    }
  }
}
